from __future__ import division
import sys, json, os, time
#
# Script that would parse the arguments passed from Model Manager
# while executing any python job. Expected format of argument is as follows
#
# python <scriptname.py> <job_id> secondary_id <?> model <model_file_absolute_path> input_file <input_data_file_abs_path> KPI-START key1 95 key2 90 KPI-END PARAM-START param1 value1 param2 value2 PARAM-END
#
# Date of creation: 8th March, 2017
#
# Author: Model Management Dev Team
# ----------------------------------------------------------------------------------------------------------
# Import libraries for downloading file from mongodb
from pymongo import MongoClient
from pprint import pprint
from gridfs import GridFSBucket
from gridfs import GridFS
import bson, string, pickle, os.path
from bson.binary import Binary
from bson.objectid import ObjectId
import pandas as pd
import os
import tempfile
import requests
import jaydebeapi
import glob
import warnings
import shutil
import string
import random
import json
import paho.mqtt.client as mqtt
import base64 
import subprocess
## ---------------------------------------------------------------------------------------------------------

arguments = {}
kpi_dictionary = {}
param_dictionary = {}
input_file = {}
output_file = {}
parsed_json_args = {}
env_config = {}
SHARED_DATA = "/shared_data"
NIFI_FOLDER = "/nifidataid"

def __customwarnformm__(message, category, filename, lineno, file=None, line=None):
	sys.stdout.write(warnings.formatwarning(message, category, filename, lineno))
warnings.showwarning = __customwarnformm__

def parseArguments(args):
    global kpi_dictionary
    global param_dictionary
    global input_file
    global output_file
    global parsed_json_args
    global arguments
    global output_mapped_file
    global env_config

    param=__buildArgs__()

    parsed_json_args=json.loads(param)
    #arguments=parsed_json_args["args"]
    #kpi_dictionary=arguments["kpi"]
    param_dictionary=parsed_json_args["params"]
    #input_file=arguments["input_file"]
    #output_file=arguments["output_file"]
    #env_config=arguments["env_config"]
#Added below for getting jobId, which is outside args json of job request.
def getJobId():
    global parsed_json_args
    return parsed_json_args["job_id"]

def about():
    print("Model Manager header library v2.1 (id: ${buildNumber.commitsha}, built: ${buildNumber.timestamp})")

def getJsonArgument(key):
    global arguments
    try:
        return arguments[key]
    except:
        e = ValueError("System does not have a value for the argument key = "+key)
        print(e)
        raise e

# Return path for model binary
def getModel():
    global arguments
    model = None
    modelPath = None
    val = arguments["model"]
    isNotModel = arguments["adhocStep"]
    
    if isNotModel:
        e = ValueError("getModel() can only be called from model's prediction_recipe")
        raise e
    elif val is None:
        e = ValueError("System does not have a value for model")
        raise e
    else:
        try:
            modelBinary = getResource(val)
            #check model is not null
            if modelBinary is not None:
                model = tempfile.NamedTemporaryFile(delete=False)
                model.write(modelBinary)           
        except:
            e = ValueError("getModel: unable to retrieve model")
            print(e)
            raise e        
    if model is not None:
        modelPath = model.name
        model.close()
    return modelPath

def getResource(fileId):
    return __streamFileDataAsBinary__(fileId).read()

def getArgument(key):
    global param_dictionary
    try:
        return param_dictionary[key]
    except:
        e= ValueError("System does not have a value for parameter key = "+key)
        print (e)
        raise e

def getEnvConfig(key):
    global env_config
    try:
        return env_config[key]
    except:
        e= ValueError("System does not have a value for parameter key = "+key)
        print (e)
        raise e

def getDataFrameFromResource(resourceName):
    '''
    download the entire content of the resource from mongodb using pandas DataRrame
    '''
    global input_file
    #input_file is Json array
    fileId = None
    for file in input_file:
        if file['name'] == resourceName:
            fileId = file['value']
    if fileId is None:
        e = ValueError("System does not have a value for input file key = "+resourceName+", please check the uploaded resource(s) name(s)")
        print (e)
        raise e
    else:
        ''' 
        Download the file content to a local file and then
        pass the file name to the caller
        '''
        content = __streamFileDataAsDf__(fileId)

        if content is None:
            e = ValueError("getDataFrameFromResource: unable to retrieve dataframe from resource: <"+resourceName+">")
            print (e)
            raise e
        return content

def saveDataFrameToResource(resourceName,data):
    '''
    Upload resource file to mongodb using pandas DataFrame
    '''
    global output_file
    uri = __getMongoDBURI__()
    client = MongoClient(uri)
    db = client.mm_resources
    fs = GridFS(db)
    fsbucket = GridFSBucket(db,bucket_name="fs")
    if not resourceName:
        e = ValueError("resource name is not provided")
        print (e)
    #output_file is Json array
    fsbucket.upload_from_stream(str(resourceName),data.to_csv(index=False).encode("UTF-8"), metadata={"jobId" : getJobId(), "name" : resourceName})

def newVersion(data):
    '''
     Create new newversion for trained binary data
    '''

    if not data:
        e = ValueError("data is not provided")
        print (e)
        raise e
    else:
        client = MongoClient(__getMongoDBURI__())
        fsbucket = GridFSBucket(client.mm_resources, bucket_name="fs")
        mm_endpoint = client.mm_resources.endpoint.find_one({"microservice_name": "python_jobserver"})
        if mm_endpoint is None:
             e = ValueError("model manager endpoint is not available")
             print (e)
             raise e
        else:
                modelBinaryName="trainedmodel"
                mm_rest_url=mm_endpoint["target_microservice_endpoint"]+"models/newtrainedversion"
                fsbucket.upload_from_stream(modelBinaryName ,data, metadata={"jobId" : getJobId(), "name" : modelBinaryName, "modelBinary":"true"})
                jsondata={"jobId" : getJobId(), "secondary_id": getJsonArgument('secondary_id')}
                r = requests.put(mm_rest_url, data=json.dumps(jsondata),headers = {'content-type': 'application/json'})
                if r.status_code!=200 or r.json().get("model_id") is None:
                       e = ValueError("Error while creating new version of the training model")
                       print (e)
                       raise e
                        
def getBinaryFromResource(resourceName):
    '''
    download the entire content of the resource binary from mongodb
    '''
    global input_file
    #input_file is Json array
    fileId = None
    for file in input_file:
        if file['name'] == resourceName:
            fileId = file['value']
    if fileId is None:
        e = ValueError("System does not have a value for input file key = "+resourceName+", please check the uploaded resource(s) name(s)")
        print (e)
        raise e
    else:
        ''' 
        Download the file content to a local file and then
        pass the file name to the caller
        '''
        content = getResource(fileId)
        
        if content is None:
            e = ValueError("getBinaryFromResource: unable to retrieve data from resource: <"+resourceName+">")
            print (e)
            raise e

        return content

def saveBinaryToResource(resourceName, data):
    '''
    Upload binary resource file to mongodb
    '''
    global output_file
    uri = __getMongoDBURI__()
    client = MongoClient(uri)
    db = client.mm_resources
    fsbucket = GridFSBucket(db,bucket_name="fs")
    if not resourceName:
        e = ValueError("resource name is not provided")
        print (e)
    if not data:
        e = ValueError("data is not provided")
        print (e)
    else:
        #output_file is Json array
        fsbucket.upload_from_stream(resourceName ,data, metadata={"jobId" : getJobId(), "name" : resourceName})

#### ---- Private methods -------------- ####
def __streamFileDataAsBinary__(fileId):
    uri = __getMongoDBURI__()
    client = MongoClient(uri)
    db = client.mm_resources
    fsbucket = GridFSBucket(db,bucket_name="fs")
    return fsbucket.open_download_stream(ObjectId(fileId))

def __streamFileDataAsDf__(fileId):
    uri = __getMongoDBURI__()
    client = MongoClient(uri)
    db = client.mm_resources
    fsbucket = GridFSBucket(db,bucket_name="fs")
    data = fsbucket.open_download_stream(ObjectId(fileId))
    pred_df=pd.read_csv(data, index_col=False)
    return pred_df

def __getMongoDBURI__():
    global env_config
    user=env_config["user"]
    pwd=env_config["pwd"]
    ip=env_config["ip"]
    port=env_config["port"]
    db=env_config["db"]
    return "mongodb://"+user+":"+pwd+"@"+ip+":"+port+"/"+db

def __buildArgs__():
    arg=""
    for index in range(len(sys.argv)-1):
        arg=arg +" "+sys.argv[index+1]
    return arg

class mmlibraryValidationWarning(UserWarning):
    pass
 
def evaluationResult(message):
    if message is not None:
        warnings.warn("mmlibrary evaluation error: "+message, mmlibraryValidationWarning, stacklevel=2)
    else:
        warnings.warn("mmlibrary evaluation error: ", mmlibraryValidationWarning, stacklevel=2)

    try:
        tempEvalFile= open("/mm_base/evaluationResult.txt","w+")
        tempEvalFile.write("mmlibrary evaluation error")
        tempEvalFile.close()
    except:
            pass
            
    
    
    
        
def __getJdbcConnDetails__(jdbcConnectionName):
    uri = __getMongoDBURI__()
    client = MongoClient(uri)
    db = client.mm_resources
    jdbcConnectionDetails = db.jdbcconnection.find_one({'jdbcconnection_name': jdbcConnectionName})
    if jdbcConnectionDetails is None:
        e = ValueError("No data present for connection name"+jdbcConnectionName)
        print (e)
        raise e
    return jdbcConnectionDetails

def __getDBConfigDetails__(type):
    uri = __getMongoDBURI__()
    client = MongoClient(uri)
    db = client.mm_resources
    dbDetails = db.dbconfigdetails.find({'runtime': 'python'})
    if dbDetails is None:
        e = ValueError("No data present for connection name"+jdbcConnectionName)
        print (e)
        raise e
    jarList=list()
    dataBaseDetails=[None,None]
    for dbDetail in dbDetails:
        if dbDetail["drv_jar_location"] is not None:
            jarList.extend(glob.glob(dbDetail["drv_jar_location"]+"/*.jar"))
        if type == dbDetail["type"]:
            dataBaseDetails[0]=dbDetail["driver_class"]
    dataBaseDetails[1]=":".join(jarList)        
    return dataBaseDetails    

def getDBConnection(jdbcConnectionName):
    jdbcConnectionDetails=__getJdbcConnDetails__(jdbcConnectionName)   
    dbDetails=__getDBConfigDetails__(jdbcConnectionDetails["type"])
    conn = jaydebeapi.connect(jclassname=dbDetails[0],
                           url=jdbcConnectionDetails["jdbc_url"], 
                           driver_args=[jdbcConnectionDetails["user_name"],
                           jdbcConnectionDetails["password"]],
                           jars=dbDetails[1])
    if jdbcConnectionDetails is None:
        e = ValueError("Cannot get connection")
        print (e)
        raise e
    return conn
    
if __name__ == '__main__':
    print("Executing header/installer python script")
    
'''
This function provides the functionality to the Data Scientist to save the Execution Output to local temporary file directory
'''    
def saveTemporary(resourceName, dataFile):
    if os.path.isfile(dataFile): 
        if bool(resourceName and resourceName.strip()):
            fileName = os.path.basename(dataFile)
            shutil.copy(dataFile, SHARED_DATA+"/"+fileName)
            os.rename(SHARED_DATA+"/"+fileName, SHARED_DATA+"/"+resourceName )
        else:
            e = ValueError("Provided resourceName is Blank")
            print (e)
            raise e  
    else:
        e = ValueError("Provided resource file = "+dataFile+" is not valid")
        print (e)
        raise e 

'''
This function provides the functionality to the Data Scientist to get the Execution Output from local temporary file directory
'''        
def getTemporary(resourceName):
    result = ''
    if bool(resourceName and resourceName.strip()):
        for (root, dirs, files) in os.walk(SHARED_DATA):
            if resourceName in files:
                result = (os.path.join(root, resourceName))
            else:
                e = ValueError("Provided file = "+resourceName+" is not found")
                print (e)
                raise e 
        return result
    else: 
        e = ValueError("Provided resourceName is Blank")
        print (e)
        raise e

def saveResource(resourceName, dataFile):
    MQTT_HOST = os.environ['MQTT_HOST']
    MQTT_PORT = int(os.environ['MQTT_PORT'])
    MQTT_KEEPALIVE_INTERVAL = 120
    MQTT_TOPIC = ''.join(random.choice(string.ascii_uppercase+ string.digits) for x in range(6))
    CLIENT_ID = ''.join(random.choice(string.ascii_uppercase+ string.digits) for x in range(6))
    RESOURCE_GROUP = ''.join(random.choice(string.ascii_uppercase+ string.digits) for x in range(7))
    #MQTT_TOPIC = 'keep'
    MQTT_MSG = ''
    infoBean = {}
    NIFI_SCRIPT = '/mm_base/nifi_invoke.sh'
    BYTE_SIZE = 1024
    INFO_JSON = "/mm_base/InfoBean.json"

    if os.path.isfile(dataFile):
       if bool(resourceName and resourceName.strip()):
            run_id = os.environ['run_id']
            entityNum = os.environ['entityNumber']
            pipe = subprocess.Popen(['/bin/bash', NIFI_SCRIPT, 'createAndStartProcessGroup',MQTT_TOPIC,CLIENT_ID,RESOURCE_GROUP], stdout=subprocess.PIPE)
            idString  = str(pipe.communicate()[0],"utf-8")
            createNifiFile(entityNum + '_' + resourceName,idString,run_id)
            # Initiate MQTT Client
            mqttc = mqtt.Client(CLIENT_ID,False)
            time.sleep(2)
	    # Connect with MQTT Broker 
            mqttc.connect(MQTT_HOST, MQTT_PORT, MQTT_KEEPALIVE_INTERVAL)
            #start the client loop to send QOS2 message
            mqttc.loop_start()
            if os.path.isfile(INFO_JSON):
                with open(INFO_JSON, encoding='utf-8') as data_file:
                    infoBean = json.loads(data_file.read())
                    infoBean['run_id'] = run_id
                    infoBean['entityNumber'] = entityNum
                    infoBean['source_device_id'] = os.environ['source_device_id']
                    infoBean['output_res_file_name'] = resourceName
      
                with open(dataFile, 'r') as f:
                    size = os.path.getsize(dataFile)
                    terminalSeq = (int)(size/BYTE_SIZE) + 1
                    infoBean['terminal_sequence_number'] = terminalSeq
                    seqNo = 0
                    while True:
                        byte_content = f.read(BYTE_SIZE)
                        seqNo += 1
                        infoBean['sequence_number'] = seqNo
                        if not byte_content:
                            break
                        base64_data = base64.b64encode(byte_content.encode())
                        base64_string = base64_data.decode('UTF-8')
                        infoBean['data'] = base64_string
                        MQTT_MSG = json.dumps(infoBean, indent=2)
                        time.sleep(2)
                        mqttc.publish(MQTT_TOPIC, MQTT_MSG,2)
                        time.sleep(2)
                #stop the client loop after sending all the data
                time.sleep(2)
                mqttc.loop_stop()
                #disconnect from client
                mqttc.disconnect()
            else:
                e = ValueError("InfoBean.JSON is not present")
                print (e)
                raise e
       else:
           e = ValueError("Provided resourceName is Blank")
           print (e)
           raise e
    else:
        e = ValueError("Provided resource file = "+dataFile+" is not valid")
        print (e)
        raise e

def createNifiFile(fileName,content,runId):
    if(os.path.isdir(NIFI_FOLDER)):
        if not os.path.exists(NIFI_FOLDER+'/'+runId):
            os.makedirs(NIFI_FOLDER+'/'+runId)
        file = open(NIFI_FOLDER+'/'+runId+'/'+fileName, 'w+')
        file.write(content)
        file.close()
    else:
        e = ValueError('Provided folder = ' + NIFI_FOLDER  + ' does not exist')
        print (e)
        raise e
