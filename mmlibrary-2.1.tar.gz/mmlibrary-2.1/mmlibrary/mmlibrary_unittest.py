import unittest
import mmlibrary as mm

class TestMMLibrary(unittest.TestCase):
    def testGetTemporary(self):
        self.assertEqual(mm.getTemporary('test.txt'),'/shared_data/test.txt')
        
    def testGetTemporaryResourceBlank(self):
        with self.assertRaises(ValueError):mm.getTemporary('')
        
    def testGetTemporaryResourceBlankMessage(self):
        with self.assertRaisesRegexp(ValueError,'Provided resourceName is Blank'):mm.getTemporary('')
        
    def testGetTemporaryFileNotFound(self):
        with self.assertRaisesRegexp(ValueError,'Provided file = invalid.txt is not found'):mm.getTemporary('invalid.txt')
        
    def testSaveTemporaryResourceBlank(self):
        with self.assertRaises(ValueError):mm.saveTemporary('','a.txt')
        
    def testSaveTemporaryResourceBlankMessage(self):
        with self.assertRaisesRegexp(ValueError,'Provided resourceName is Blank'):mm.saveTemporary('','a.txt')
        
    def testSaveTemporaryInvalidFile(self):
        with self.assertRaises(ValueError):mm.saveTemporary('test.txt','invalid.txt')
         
    def testSaveTemporaryInvalidFileMessage(self):
        with self.assertRaisesRegexp(ValueError,'Provided resource file = invalid.txt is not valid'):mm.saveTemporary('test.txt','invalid.txt')
        
         

if __name__ == '__main__':
    unittest.main()