from setuptools import setup, find_packages

setup(
    name='mmlibrary',
    version='2.1',
    description='Python Job Server header package for model manager',
    long_description='This python library will provide all needed functions for data scientists to use model manager',
    packages=['mmlibrary'],
    classifiers=['Programming Language :: Python :: 3'],
    url='https://www.accenture.com/us-en/service-accenture-insights-platform',
    install_requires=['pandas==0.20.2','pymongo==3.5.1','JayDeBeApi==1.1.1','requests==2.18.4'],
    python_requires='>=3.3',
    author='AIP Design Studio Model Manager',
    author_email='nirmalya.chakraborty@accenture.com',
    keywords='Python Job Server header package for AIP Design Studio Model Manager',
    zip_safe=False
)
