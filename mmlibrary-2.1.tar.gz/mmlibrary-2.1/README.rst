This source distribution contains the library function required for running any python recipe using model management.

Supported library functions are - 

a) parseArguments
b) getJobId
c) getArgument
d) getKpi
e) getParam
f) getInputFile
g) getOutputFile
